Lucky Cold Coffee — Vercel deployment package

Contents
- index.html: storefront, customer login/cart/orders, admin screens, and admin password recovery UI
- vercel.json: clean URL configuration

Deployment
1. Open the existing Lucky Cold Coffee project in Vercel.
2. Deploy the updated source from GitHub or upload this folder using a supported deployment workflow.
3. Wait for the deployment status to become Ready.
4. Test menu loading, customer login, cart/checkout, customer order history, admin login, menu management, order updates, and password recovery.

Important
- This package uses the existing Supabase project URL and publishable key embedded in index.html.
- Supabase must authorize the production domain in its Auth URL configuration if Auth redirect/recovery flows require it.
- The Online Payment option is a UI option only unless a payment provider is separately integrated.
- Do not switch off the existing Netlify site until the Vercel deployment is verified.
